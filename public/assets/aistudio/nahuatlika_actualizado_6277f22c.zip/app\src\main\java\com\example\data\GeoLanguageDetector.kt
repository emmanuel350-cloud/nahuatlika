package com.example.data

import android.annotation.SuppressLint
import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

data class GeoLanguageResult(
    val state: String,
    val locality: String,
    val regionName: String,
    val languageCode: String,          // "Nahuatl", "Totona", "Maya", "Zapoteco", "Mixteco", "Otomi"
    val languageDisplayName: String,
    val variantName: String,
    val culturalSummary: String,
    val greetingPhrase: String,
    val flagOrIcon: String,
    val isExactRegionMatch: Boolean = true
)

object GeoLanguageDetector {

    /**
     * Obtains the user's current or last known GPS location using standard Android LocationManager.
     */
    @SuppressLint("MissingPermission")
    fun getLastKnownLocation(context: Context): Location? {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
        val providers = locationManager.getProviders(true)
        var bestLocation: Location? = null

        for (provider in providers) {
            try {
                val l = locationManager.getLastKnownLocation(provider) ?: continue
                if (bestLocation == null || l.accuracy < bestLocation.accuracy) {
                    bestLocation = l
                }
            } catch (_: SecurityException) {}
        }
        return bestLocation
    }

    /**
     * Asynchronously detects the indigenous ancestral language of the user's location.
     * Uses Geocoder reverse lookup combined with geographic coordinates bounding-boxes for all 32 Mexican states.
     */
    suspend fun detectIndigenousLanguage(
        context: Context,
        location: Location? = null
    ): GeoLanguageResult = withContext(Dispatchers.IO) {
        val loc = location ?: getLastKnownLocation(context)

        var state = ""
        var locality = ""

        if (loc != null) {
            try {
                if (Geocoder.isPresent()) {
                    val geocoder = Geocoder(context, Locale("es", "MX"))
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        val addresses = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)
                        if (!addresses.isNullOrEmpty()) {
                            val addr = addresses[0]
                            state = addr.adminArea ?: ""
                            locality = addr.locality ?: addr.subAdminArea ?: ""
                        }
                    } else {
                        @Suppress("DEPRECATION")
                        val addresses = geocoder.getFromLocation(loc.latitude, loc.longitude, 1)
                        if (!addresses.isNullOrEmpty()) {
                            val addr = addresses[0]
                            state = addr.adminArea ?: ""
                            locality = addr.locality ?: addr.subAdminArea ?: ""
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        return@withContext resolveLanguageByRegion(
            state = state,
            locality = locality,
            latitude = loc?.latitude,
            longitude = loc?.longitude
        )
    }

    /**
     * Resolves the regional indigenous language and variant for ALL 32 states of the Mexican Republic.
     */
    fun resolveLanguageByRegion(
        state: String,
        locality: String,
        latitude: Double?,
        longitude: Double?
    ): GeoLanguageResult {
        val stateNorm = state.lowercase(Locale.ROOT).trim()
        val localityNorm = locality.lowercase(Locale.ROOT).trim()

        // =========================================================================
        // 1. ESPECIALIDADES POR MICRO-REGIÓN / MUNICIPIO EMBLEMÁTICO
        // =========================================================================
        if (localityNorm.contains("papantla") || localityNorm.contains("poza rica") || localityNorm.contains("tajín") || localityNorm.contains("tajin") || localityNorm.contains("coatzintla") || localityNorm.contains("cazones") || localityNorm.contains("zozocolco")) {
            return GeoLanguageResult(
                state = if (state.isNotBlank()) state else "Veracruz",
                locality = locality.ifBlank { "Papantla de Olarte" },
                regionName = "Totonacapan Sagrado (Costa de Veracruz)",
                languageCode = "Totona",
                languageDisplayName = "Totonaco",
                variantName = "Ceremonial de Papantla",
                culturalSummary = "Tierra de los Tres Corazones, aroma a vainilla y la gran pirámide de los Nichos en El Tajín.",
                greetingPhrase = "¡Tlan tlan! Bienvenido al sagrado Totonacapan aromático.",
                flagOrIcon = "🌸"
            )
        }

        if (localityNorm.contains("juchitán") || localityNorm.contains("juchitan") || localityNorm.contains("tehuantepec") || localityNorm.contains("salina cruz") || localityNorm.contains("ixtepec")) {
            return GeoLanguageResult(
                state = if (state.isNotBlank()) state else "Oaxaca",
                locality = locality.ifBlank { "Istmo de Tehuantepec" },
                regionName = "Istmo de Tehuantepec (Oaxaca)",
                languageCode = "Zapoteco",
                languageDisplayName = "Zapoteco",
                variantName = "Canto de Juchitán",
                culturalSummary = "Cuna de las Fiestas de las Velas, poesía viva y el sonoro Diidxazá de las mujeres zapotecas.",
                greetingPhrase = "¡Padiuxi! Bienvenido a la tierra de la flor de guie' chaachi.",
                flagOrIcon = "🌺"
            )
        }

        if (localityNorm.contains("ixmiquilpan") || localityNorm.contains("actopan") || localityNorm.contains("cardonal") || localityNorm.contains("tasquillo") || localityNorm.contains("el arenal")) {
            return GeoLanguageResult(
                state = if (state.isNotBlank()) state else "Hidalgo",
                locality = locality.ifBlank { "Valle del Mezquital" },
                regionName = "Valle del Mezquital (Hidalgo)",
                languageCode = "Otomi",
                languageDisplayName = "Otomí",
                variantName = "Viento de Mezquital",
                culturalSummary = "Tierra ancestral del pueblo Hñähñu entre magueyes, cantos sagrados y tenangos floridos.",
                greetingPhrase = "¡Hats'i! Las cactáceas del Valle del Mezquital te saludan.",
                flagOrIcon = "🌵"
            )
        }

        if (localityNorm.contains("amealco") || localityNorm.contains("tolimán") || localityNorm.contains("toliman") || localityNorm.contains("cadereyta")) {
            return GeoLanguageResult(
                state = if (state.isNotBlank()) state else "Querétaro",
                locality = locality.ifBlank { "Amealco de Bonfil" },
                regionName = "Región Ñäñho de Amealco (Querétaro)",
                languageCode = "Otomi",
                languageDisplayName = "Otomí",
                variantName = "Acento Lelé Queretano",
                culturalSummary = "Hogar de la embajadora artesanal Lelé y la hermosa lengua otomí de las faldas serranas.",
                greetingPhrase = "¡Ki hats'i! La muñeca sagrada Lelé y el pueblo otomí te reciben.",
                flagOrIcon = "🪆"
            )
        }

        if (localityNorm.contains("cuetzalan") || localityNorm.contains("zacatlán") || localityNorm.contains("zacatlan") || localityNorm.contains("huauchinango") || localityNorm.contains("teziutlán") || localityNorm.contains("teziutlan")) {
            return GeoLanguageResult(
                state = if (state.isNotBlank()) state else "Puebla",
                locality = locality.ifBlank { "Sierra Norte de Puebla" },
                regionName = "Sierra Mágica de Cuetzalan (Puebla)",
                languageCode = "Totona",
                languageDisplayName = "Totonaco",
                variantName = "Enérgico de montaña",
                culturalSummary = "Montañas envueltas en niebla, cascadas sagradas y los hermosos huipiles totonacos de Cuetzalan.",
                greetingPhrase = "¡Tlan tlan! Los espíritus de la sierra verde te reciben.",
                flagOrIcon = "⛰️"
            )
        }

        // =========================================================================
        // 2. MAPEO EXHAUSTIVO DE LOS 32 ESTADOS DE LA REPÚBLICA MEXICANA
        // =========================================================================

        // 1. AGUASCALIENTES
        if (stateNorm.contains("aguascalientes")) {
            return GeoLanguageResult(
                state = "Aguascalientes",
                locality = locality.ifBlank { "Valle de Aguascalientes" },
                regionName = "Tierra Caxcán y Chichimeca (Aguascalientes)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Tierra de la gente buena, tradición caxcán y cruce histórico del Camino Real de Tierra Adentro.",
                greetingPhrase = "¡Niltze! Bienvenido a las tierras cálidas de Aguascalientes.",
                flagOrIcon = "🍇"
            )
        }

        // 2. BAJA CALIFORNIA
        if (stateNorm.contains("baja california sur")) {
            return GeoLanguageResult(
                state = "Baja California Sur",
                locality = locality.ifBlank { "Península del Sur" },
                regionName = "Pinturas Rupestres y Mares del Sur (Baja California Sur)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Mares sagrados de Cortés y milenarias pinturas rupestres bajo el sol peninsular.",
                greetingPhrase = "¡Niltze! Bienvenido al paraíso peninsular de Baja California Sur.",
                flagOrIcon = "🏖️"
            )
        }

        // 3. BAJA CALIFORNIA (NORTE)
        if (stateNorm.contains("baja california")) {
            return GeoLanguageResult(
                state = "Baja California",
                locality = locality.ifBlank { "Frontera Norte" },
                regionName = "Frontera Intercultural de Baja California",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Puerta del Pacífico y tierra fronteriza donde convergen las lenguas ancestrales de todo México.",
                greetingPhrase = "¡Niltze! Saludos fraternales desde la península de Baja California.",
                flagOrIcon = "🐋"
            )
        }

        // 4. CAMPECHE
        if (stateNorm.contains("campeche")) {
            return GeoLanguageResult(
                state = "Campeche",
                locality = locality.ifBlank { "Calakmul / Camino Real" },
                regionName = "Selvas de Calakmul y Camino Real Maya (Campeche)",
                languageCode = "Maya",
                languageDisplayName = "Maya",
                variantName = "Maya Yucateco Glotalizado",
                culturalSummary = "Selvas profundas de Calakmul y baluartes que custodian la milenaria cultura maya peninsular.",
                greetingPhrase = "¡Ba'ax ka wa'alik! Bienvenido a la selva y baluartes mayas de Campeche.",
                flagOrIcon = "🏰"
            )
        }

        // 5. CHIAPAS
        if (stateNorm.contains("chiapas")) {
            return GeoLanguageResult(
                state = "Chiapas",
                locality = locality.ifBlank { "Selva Chiapaneca" },
                regionName = "Montañas Sagradas y Selva Lacandona (Chiapas)",
                languageCode = "Maya",
                languageDisplayName = "Maya",
                variantName = "Nosótrico Tojolabal",
                culturalSummary = "Místicas montañas mayas con la profunda filosofía del nosotros (tojolabal) y la selva lacandona.",
                greetingPhrase = "¡K'alal k'ojol! Bienvenido a la neblina y cascadas sagradas de Chiapas.",
                flagOrIcon = "🌿"
            )
        }

        // 6. CHIHUAHUA
        if (stateNorm.contains("chihuahua")) {
            return GeoLanguageResult(
                state = "Chihuahua",
                locality = locality.ifBlank { "Sierra Tarahumara" },
                regionName = "Barrancas del Cobre y Gran Familia Yuto-Nahua (Chihuahua)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl de la Huasteca veracruzana",
                culturalSummary = "Tierra de los pies ligeros (Rarámuri) y la gran raíz ancestral yuto-azteca de las Barrancas del Cobre.",
                greetingPhrase = "¡Niltze! Las majestuosas Barrancas del Cobre de Chihuahua te saludan.",
                flagOrIcon = "🦅"
            )
        }

        // 7. CIUDAD DE MÉXICO
        if (stateNorm.contains("ciudad de m") || stateNorm.contains("cdmx") || stateNorm.contains("distrito federal") || stateNorm.contains("tenochtitlan") || stateNorm == "df") {
            return GeoLanguageResult(
                state = "Ciudad de México",
                locality = locality.ifBlank { "Cuenca del Anáhuac" },
                regionName = "Gran Cuenca del Anáhuac y Tenochtitlan (CDMX)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "El mismísimo corazón del Imperio Mexica, donde el águila se posó sobre el nopal en el lago sagrado.",
                greetingPhrase = "¡Niltze, noble guerrero! Estás en el supremo corazón de Tenochtitlan.",
                flagOrIcon = "🦅"
            )
        }

        // 8. COAHUILA
        if (stateNorm.contains("coahuila")) {
            return GeoLanguageResult(
                state = "Coahuila",
                locality = locality.ifBlank { "San Esteban de la Nueva Tlaxcala" },
                regionName = "Herencia Tlaxcalteca del Desierto (Coahuila)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Consonante limpia de la Malinche",
                culturalSummary = "Legado vivo de las familias tlaxcaltecas que fundaron el Saltillo y sembraron el náhuatl y el sarape en el norte.",
                greetingPhrase = "¡Niltze! Bienvenido a la tierra de Cuatro Ciénegas y el sarape coahuilense.",
                flagOrIcon = "🏜️"
            )
        }

        // 9. COLIMA
        if (stateNorm.contains("colima")) {
            return GeoLanguageResult(
                state = "Colima",
                locality = locality.ifBlank { "Señorío de Coliman" },
                regionName = "Antiguo Señorío de Coliman (Colima)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Faldas del Volcán de Fuego y perritos cebados danzantes del antiguo señorío nahua de Coliman.",
                greetingPhrase = "¡Niltze! El guardián del Volcán de Fuego bendice tu llegada a Colima.",
                flagOrIcon = "🌋"
            )
        }

        // 10. DURANGO
        if (stateNorm.contains("durango")) {
            return GeoLanguageResult(
                state = "Durango",
                locality = locality.ifBlank { "Sierra Madre de Durango" },
                regionName = "Confederación de la Sierra y Raíces Mexicaneras (Durango)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Serranías de pinos de los mexicaneros duranguenses y raíces guerreras del Valle del Guadiana.",
                greetingPhrase = "¡Niltze! Bienvenido a la imponente Sierra Madre de Durango.",
                flagOrIcon = "🌲"
            )
        }

        // 11. ESTADO DE MÉXICO
        if (stateNorm.contains("estado de m") || stateNorm.contains("edomex") || stateNorm == "méxico" || stateNorm == "mexico") {
            return GeoLanguageResult(
                state = "Estado de México",
                locality = locality.ifBlank { "Teotihuacan / Texcoco" },
                regionName = "Valle de Teotihuacan y Señorío de Texcoco (Edomex)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Tierra del rey poeta Netzahualcóyotl y las pirámides del Sol y la Luna de Teotihuacan.",
                greetingPhrase = "¡Niltze! Bienvenido a la mística ciudad de los dioses de Teotihuacan.",
                flagOrIcon = "☀️"
            )
        }

        // 12. GUANAJUATO
        if (stateNorm.contains("guanajuato")) {
            return GeoLanguageResult(
                state = "Guanajuato",
                locality = locality.ifBlank { "San Miguel / Bajío" },
                regionName = "Cuna Chichimeca y Otomí del Bajío (Guanajuato)",
                languageCode = "Otomi",
                languageDisplayName = "Otomí",
                variantName = "Viento de Mezquital",
                culturalSummary = "Minas de plata, cañadas de la insurgencia y la milenaria raíz otomí-chichimeca de San Miguel.",
                greetingPhrase = "¡Hats'i! Bienvenido a la noble cuna histórica de Guanajuato.",
                flagOrIcon = "🔔"
            )
        }

        // 13. GUERRERO
        if (stateNorm.contains("guerrero")) {
            if (localityNorm.contains("tlapa") || localityNorm.contains("metlatónoc") || localityNorm.contains("cochoapa")) {
                return GeoLanguageResult(
                    state = "Guerrero",
                    locality = locality.ifBlank { "La Montaña de Guerrero" },
                    regionName = "La Montaña Mixteca de Guerrero",
                    languageCode = "Mixteco",
                    languageDisplayName = "Mixteco",
                    variantName = "Vigoroso de la Montaña",
                    culturalSummary = "Pueblo de la lluvia en las altas cumbres de la Montaña guerrerense.",
                    greetingPhrase = "¡Kuni! La lluvia y la fuerza de la Montaña de Guerrero te bendicen.",
                    flagOrIcon = "🌧️"
                )
            } else {
                return GeoLanguageResult(
                    state = "Guerrero",
                    locality = locality.ifBlank { "Chilapa / Tixtla" },
                    regionName = "Tierra Jaguar de la Montaña (Guerrero)",
                    languageCode = "Nahuatl",
                    languageDisplayName = "Náhuatl",
                    variantName = "Asertivo de Guerrero",
                    culturalSummary = "Fieles guardianes de la Montaña, rito sagrado de la Tigrada y cajas de Olinalá.",
                    greetingPhrase = "¡Niltze! La bravura del jaguar te da la bienvenida a Guerrero.",
                    flagOrIcon = "🐆"
                )
            }
        }

        // 14. HIDALGO
        if (stateNorm.contains("hidalgo")) {
            if (localityNorm.contains("huejutla") || localityNorm.contains("atlapexco") || localityNorm.contains("san felipe")) {
                return GeoLanguageResult(
                    state = "Hidalgo",
                    locality = locality.ifBlank { "Huejutla de Reyes" },
                    regionName = "Huasteca Hidalguense",
                    languageCode = "Nahuatl",
                    languageDisplayName = "Náhuatl",
                    variantName = "Náhuatl de la Huasteca veracruzana",
                    culturalSummary = "Corazón del Xantolo hidalguense, aromas a copal y huapangos de la Huasteca.",
                    greetingPhrase = "¡Pialli! Bienvenido a la Huasteca hidalguense y la fiesta del Xantolo.",
                    flagOrIcon = "🌽"
                )
            } else {
                return GeoLanguageResult(
                    state = "Hidalgo",
                    locality = locality.ifBlank { "Valle del Mezquital / Tula" },
                    regionName = "Valle del Mezquital y Atlantes de Tula (Hidalgo)",
                    languageCode = "Otomi",
                    languageDisplayName = "Otomí",
                    variantName = "Viento de Mezquital",
                    culturalSummary = "Suelo de gigantes atlantes de Tula y el sabio pueblo tejedor otomí Hñähñu.",
                    greetingPhrase = "¡Hats'i! Los antiguos toltecas y el pueblo Hñähñu bendicen tu llegada.",
                    flagOrIcon = "🗿"
                )
            }
        }

        // 15. JALISCO
        if (stateNorm.contains("jalisco")) {
            return GeoLanguageResult(
                state = "Jalisco",
                locality = locality.ifBlank { "Valle de Atemajac / Tuxpan" },
                regionName = "Señorío Nahua de Tuxpan y Occidente (Jalisco)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Tierra del agave azul, el son mestizo y la histórica presencia náhuatl del pueblo de Tuxpan.",
                greetingPhrase = "¡Niltze! Bienvenido a la tierra del maíz y la tradición de Jalisco.",
                flagOrIcon = "🎺"
            )
        }

        // 16. MICHOACÁN
        if (stateNorm.contains("michoac")) {
            return GeoLanguageResult(
                state = "Michoacán",
                locality = locality.ifBlank { "Costa Nahua de Michoacán" },
                regionName = "Costa Nahua y Bosques Sagrados (Michoacán)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Lagos sagrados de Pátzcuaro, bosques de la mariposa monarca y náhuatl costero de Aquila.",
                greetingPhrase = "¡Niltze! Los bosques de la mariposa monarca y la costa michoacana te reciben.",
                flagOrIcon = "🦋"
            )
        }

        // 17. MORELOS
        if (stateNorm.contains("morelos")) {
            return GeoLanguageResult(
                state = "Morelos",
                locality = locality.ifBlank { "Tepoztlán / Cuentepec" },
                regionName = "Cerros Sagrados del Tepozteco y Cuentepec (Morelos)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Pirámide del Tepozteco en la cima de la montaña y la lengua náhuatl viva de Cuentepec.",
                greetingPhrase = "¡Niltze! El cerro sagrado del Tepozteco te da la bienvenida a Morelos.",
                flagOrIcon = "🌺"
            )
        }

        // 18. NAYARIT
        if (stateNorm.contains("nayarit")) {
            return GeoLanguageResult(
                state = "Nayarit",
                locality = locality.ifBlank { "Mexcaltitán / Aztlán" },
                regionName = "Mítica Cuna de Aztlán (Nayarit)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "La mítica isla de Mexcaltitán, punto de partida de la legendaria peregrinación mexica hacia Tenochtitlan.",
                greetingPhrase = "¡Niltze! Bienvenido a la legendaria cuna azteca de Nayarit.",
                flagOrIcon = "🛶"
            )
        }

        // 19. NUEVO LEÓN
        if (stateNorm.contains("nuevo le")) {
            return GeoLanguageResult(
                state = "Nuevo León",
                locality = locality.ifBlank { "Bustamante / Monterrey" },
                regionName = "Herencia Tlaxcalteca de Bustamante (Nuevo León)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Consonante limpia de la Malinche",
                culturalSummary = "El Cerro de la Silla y el legado de los tlaxcaltecas fundadores que trajeron el nogal y la panadería tradicional.",
                greetingPhrase = "¡Niltze! El Cerro de la Silla y el viento del noreste te dan la bienvenida.",
                flagOrIcon = "⛰️"
            )
        }

        // 20. OAXACA
        if (stateNorm.contains("oaxaca")) {
            if (localityNorm.contains("huajuapan") || localityNorm.contains("tlaxiaco") || localityNorm.contains("juxtlahuaca") || localityNorm.contains("mixteca") || (longitude != null && longitude < -97.2)) {
                return GeoLanguageResult(
                    state = "Oaxaca",
                    locality = locality.ifBlank { "Mixteca Oaxaqueña" },
                    regionName = "Ñuu Savi: País de la Lluvia (Oaxaca)",
                    languageCode = "Mixteco",
                    languageDisplayName = "Mixteco",
                    variantName = "Cadencia Pluvial Mixteca",
                    culturalSummary = "Pueblo de las nubes y la lluvia, legendarios creadores de códices dorados de Ocho Venado Garra de Jaguar.",
                    greetingPhrase = "¡Kuni! Que la bendición de la lluvia acompañe tus pasos.",
                    flagOrIcon = "🌧️"
                )
            } else {
                return GeoLanguageResult(
                    state = "Oaxaca",
                    locality = locality.ifBlank { "Valles Centrales / Monte Albán" },
                    regionName = "Valles Centrales y Monte Albán (Oaxaca)",
                    languageCode = "Zapoteco",
                    languageDisplayName = "Zapoteco",
                    variantName = "Canto de Juchitán",
                    culturalSummary = "Tierra de los Ben'Zaa (gente de las nubes) y la gran metrópoli prehispánica de Monte Albán.",
                    greetingPhrase = "¡Padiux! Bienvenido al corazón de la sabiduría zapoteca.",
                    flagOrIcon = "🏺"
                )
            }
        }

        // 21. PUEBLA
        if (stateNorm.contains("puebla")) {
            if (localityNorm.contains("tehuac") || localityNorm.contains("coxcatl") || localityNorm.contains("sierra negra") || (latitude != null && latitude < 18.9)) {
                return GeoLanguageResult(
                    state = "Puebla",
                    locality = locality.ifBlank { "Valle de Tehuacán" },
                    regionName = "Valle de Tehuacán y Sierra Negra (Puebla)",
                    languageCode = "Nahuatl",
                    languageDisplayName = "Náhuatl",
                    variantName = "Tono elevado de la Sierra de Tehuacán",
                    culturalSummary = "Cuna del maíz más antiguo de Mesoamérica en las cuevas de Coxcatlán y guardianes del Popocatépetl.",
                    greetingPhrase = "¡Niltze! Bienvenido a las tierras poblanas del maíz eterno.",
                    flagOrIcon = "🌋"
                )
            } else {
                return GeoLanguageResult(
                    state = "Puebla",
                    locality = locality.ifBlank { "Sierra Norte de Puebla" },
                    regionName = "Sierra Totonaca de Puebla",
                    languageCode = "Totona",
                    languageDisplayName = "Totonaco",
                    variantName = "Enérgico de montaña",
                    culturalSummary = "Montañas de niebla, textiles de telar de cintura y el hablar melódico totonaco de la sierra.",
                    greetingPhrase = "¡Tlan tlan! Te damos la bienvenida a la sierra poblana.",
                    flagOrIcon = "⛰️"
                )
            }
        }

        // 22. QUERÉTARO
        if (stateNorm.contains("quer")) {
            return GeoLanguageResult(
                state = "Querétaro",
                locality = locality.ifBlank { "Peña de Bernal / Amealco" },
                regionName = "Peña Sagrada de Bernal y Pueblo Ñäñho (Querétaro)",
                languageCode = "Otomi",
                languageDisplayName = "Otomí",
                variantName = "Acento Lelé Queretano",
                culturalSummary = "La gran Peña de Bernal, muñecas sagradas Lelé y cantos del semidesierto queretano.",
                greetingPhrase = "¡Ki hats'i! La muñeca Lelé y el pueblo otomí te reciben en Querétaro.",
                flagOrIcon = "🪆"
            )
        }

        // 23. QUINTANA ROO
        if (stateNorm.contains("quintana roo")) {
            return GeoLanguageResult(
                state = "Quintana Roo",
                locality = locality.ifBlank { "Tulum / Costa Maya" },
                regionName = "Costa Maya y Santuario de Tulum (Quintana Roo)",
                languageCode = "Maya",
                languageDisplayName = "Maya",
                variantName = "Maya Yucateco Glotalizado",
                culturalSummary = "Mares turquesa, la laguna de los siete colores de Bacalar y los templos mayas frente al océano.",
                greetingPhrase = "¡Ba'ax ka wa'alik! Bienvenido a la mística Costa Maya de Quintana Roo.",
                flagOrIcon = "🌊"
            )
        }

        // 24. SAN LUIS POTOSÍ
        if (stateNorm.contains("san luis potos") || stateNorm.contains("slp")) {
            return GeoLanguageResult(
                state = "San Luis Potosí",
                locality = locality.ifBlank { "Huasteca Potosina / Xilitla" },
                regionName = "Huasteca Potosina y Pueblo Téenek (San Luis Potosí)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl de la Huasteca veracruzana",
                culturalSummary = "Ríos color turquesa, el sótano de las golondrinas y la frondosa huasteca náhuatl y téenek.",
                greetingPhrase = "¡Pialli! Bienvenido a las aguas y cascadas sagradas de la Huasteca Potosina.",
                flagOrIcon = "💎"
            )
        }

        // 25. SINALOA
        if (stateNorm.contains("sinaloa")) {
            return GeoLanguageResult(
                state = "Sinaloa",
                locality = locality.ifBlank { "Valles de Sinaloa" },
                regionName = "Costa del Pacífico y Raíz Yuto-Nahua (Sinaloa)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "Valles agrícolas fértiles, la sagrada danza del venado y la herencia viva yuto-azteca.",
                greetingPhrase = "¡Niltze! Los vientos del Mar de Cortés te dan la bienvenida a Sinaloa.",
                flagOrIcon = "🦌"
            )
        }

        // 26. SONORA
        if (stateNorm.contains("sonora")) {
            return GeoLanguageResult(
                state = "Sonora",
                locality = locality.ifBlank { "Gran Desierto de Sonora" },
                regionName = "Gran Desierto y Pueblos Guerreros Yuto-Aztecas (Sonora)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl Central / Imperial",
                culturalSummary = "El majestuoso desierto de Altar, pueblos yaquis de gran dignidad y raíces de la familia lingüística yuto-azteca.",
                greetingPhrase = "¡Niltze! Saludos desde la inmensidad del gran desierto sonorense.",
                flagOrIcon = "🌵"
            )
        }

        // 27. TABASCO
        if (stateNorm.contains("tabasco")) {
            return GeoLanguageResult(
                state = "Tabasco",
                locality = locality.ifBlank { "La Chontalpa / Villahermosa" },
                regionName = "Tierra Olmeca del Cacao y Fusión Chontal (Tabasco)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Fusión Maya-Chontal",
                culturalSummary = "Tierra de las colosales cabezas olmecas, pantanos sagrados de Centla y el chocolate prehispánico.",
                greetingPhrase = "¡Niltze! Bienvenido a la tierra olmeca y del cacao sagrado de Tabasco.",
                flagOrIcon = "🍫"
            )
        }

        // 28. TAMAULIPAS
        if (stateNorm.contains("tamaulipas")) {
            return GeoLanguageResult(
                state = "Tamaulipas",
                locality = locality.ifBlank { "Huasteca Tamaulipeca" },
                regionName = "Huasteca Tamaulipeca y Río Bravo (Tamaulipas)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Náhuatl de la Huasteca veracruzana",
                culturalSummary = "Ríos caudalosos de la sierra tamaulipeca y la centenaria memoria del huapango huasteco.",
                greetingPhrase = "¡Pialli! Saludos desde las tierras huastecas de Tamaulipas.",
                flagOrIcon = "🌾"
            )
        }

        // 29. TLAXCALA
        if (stateNorm.contains("tlaxcala")) {
            if (localityNorm.contains("ixtenco")) {
                return GeoLanguageResult(
                    state = "Tlaxcala",
                    locality = locality.ifBlank { "San Juan Ixtenco" },
                    regionName = "Pueblo Otomí Yümu de Ixtenco (Tlaxcala)",
                    languageCode = "Otomi",
                    languageDisplayName = "Otomí",
                    variantName = "Yümu de Tlaxcala",
                    culturalSummary = "El último bastión otomí de Tlaxcala con el hermoso maíz de colores y bordados en pepenado.",
                    greetingPhrase = "¡Hats'i! Los maíces sagrados de Ixtenco te bendicen.",
                    flagOrIcon = "🌽"
                )
            } else {
                return GeoLanguageResult(
                    state = "Tlaxcala",
                    locality = locality.ifBlank { "Tierras de la Malinche" },
                    regionName = "Faldas del Volcán Matlalcueyetl y Señorío Tlaxcalteca",
                    languageCode = "Nahuatl",
                    languageDisplayName = "Náhuatl",
                    variantName = "Consonante limpia de la Malinche",
                    culturalSummary = "Noble señorío guerrero de los cuatro altépetl y el pan de fiesta tradicional bajo el volcán.",
                    greetingPhrase = "¡Niltze! Bienvenido a la cuna de la nación tlaxcalteca.",
                    flagOrIcon = "🌲"
                )
            }
        }

        // 30. VERACRUZ
        if (stateNorm.contains("veracruz")) {
            if (localityNorm.contains("tuxpan") || localityNorm.contains("chicontepec") || localityNorm.contains("tantoyuca") || localityNorm.contains("tempoal") || localityNorm.contains("huasteca") || (latitude != null && latitude > 20.9)) {
                return GeoLanguageResult(
                    state = "Veracruz",
                    locality = locality.ifBlank { "Huasteca Veracruzana" },
                    regionName = "Huasteca Veracruzana Sagrada",
                    languageCode = "Nahuatl",
                    languageDisplayName = "Náhuatl",
                    variantName = "Náhuatl de la Huasteca veracruzana",
                    culturalSummary = "La tierra fecunda del son huasteco, el maíz tierno y la milpa comunitaria.",
                    greetingPhrase = "¡Pialli! Bienvenido a la Huasteca veracruzana, tierra de cantos y flores.",
                    flagOrIcon = "🌽"
                )
            } else {
                return GeoLanguageResult(
                    state = "Veracruz",
                    locality = locality.ifBlank { "Costa del Golfo" },
                    regionName = "Costa de Veracruz (Totonacapan)",
                    languageCode = "Totona",
                    languageDisplayName = "Totonaco",
                    variantName = "Ceremonial de Papantla",
                    culturalSummary = "Costas y valles aromáticos del Tajín y los danzantes voladores que tocan el cielo.",
                    greetingPhrase = "¡Tlan tlan! Te damos la bienvenida a la costa veracruzana.",
                    flagOrIcon = "🌊"
                )
            }
        }

        // 31. YUCATÁN
        if (stateNorm.contains("yucat")) {
            return GeoLanguageResult(
                state = "Yucatán",
                locality = locality.ifBlank { "Chichén Itzá / Mérida" },
                regionName = "El Sagrado Corazón del Mayab (Yucatán)",
                languageCode = "Maya",
                languageDisplayName = "Maya",
                variantName = "Maya Yucateco Glotalizado",
                culturalSummary = "Cuna de los sabios astrónomos del Chilam Balam, cenotes sagrados y Chichén Itzá.",
                greetingPhrase = "¡Ba'ax ka wa'alik! Bienvenido a la cuna del Mayab en Yucatán.",
                flagOrIcon = "🏛️"
            )
        }

        // 32. ZACATECAS
        if (stateNorm.contains("zacatecas")) {
            return GeoLanguageResult(
                state = "Zacatecas",
                locality = locality.ifBlank { "La Quemada / Chalchihuites" },
                regionName = "Fortalezas Prehispánicas de La Quemada (Zacatecas)",
                languageCode = "Nahuatl",
                languageDisplayName = "Náhuatl",
                variantName = "Consonante limpia de la Malinche",
                culturalSummary = "Templos prehispánicos de La Quemada y el histórico Camino Real de la Plata.",
                greetingPhrase = "¡Niltze! Las fortalezas prehispánicas de La Quemada te dan la bienvenida.",
                flagOrIcon = "⛏️"
            )
        }

        // =========================================================================
        // 3. COORDENADAS GEOGRÁFICAS EN MÉXICO (SI GEOCODER NO DEVUELVE TEXTO)
        // =========================================================================
        if (latitude != null && longitude != null) {
            // Península de Yucatán & Quintana Roo & Campeche
            if (latitude in 17.5..21.8 && longitude in -92.5..-86.5) {
                return GeoLanguageResult(
                    state = "Península de Yucatán",
                    locality = "Territorio del Mayab",
                    regionName = "Península de Yucatán y Selva Maya",
                    languageCode = "Maya",
                    languageDisplayName = "Maya",
                    variantName = "Maya Yucateco Glotalizado",
                    culturalSummary = "Coordenadas dentro del territorio sagrado de la cultura Maya.",
                    greetingPhrase = "¡Ba'ax ka wa'alik! Coordenadas mayas detectadas.",
                    flagOrIcon = "🏛️"
                )
            }
            // Oaxaca (Valles / Sierra / Mixteca)
            if (latitude in 15.5..18.5 && longitude in -98.5..-93.8) {
                return GeoLanguageResult(
                    state = "Oaxaca",
                    locality = "Valles y Sierras de Oaxaca",
                    regionName = "Oaxaca Ancestral",
                    languageCode = "Zapoteco",
                    languageDisplayName = "Zapoteco",
                    variantName = "Canto de Juchitán",
                    culturalSummary = "Coordenadas en las tierras sagradas de los Valles Centrales y del Istmo oaxaqueño.",
                    greetingPhrase = "¡Padiuxi! Coordenadas oaxaqueñas detectadas.",
                    flagOrIcon = "🌺"
                )
            }
            // Huasteca & Costa de Veracruz
            if (latitude in 20.0..22.8 && longitude in -98.8..-96.5) {
                return GeoLanguageResult(
                    state = "Veracruz",
                    locality = "Región Huasteca / Totonacapan",
                    regionName = "Huasteca y Totonacapan",
                    languageCode = "Nahuatl",
                    languageDisplayName = "Náhuatl",
                    variantName = "Náhuatl de la Huasteca veracruzana",
                    culturalSummary = "Coordenadas dentro de la cuenca huasteca y del golfo de México.",
                    greetingPhrase = "¡Pialli! Coordenadas de la Huasteca veracruzana.",
                    flagOrIcon = "🌽"
                )
            }
        }

        // =========================================================================
        // 4. RECOMENDACIÓN POR DEFECTO PARA TODO MÉXICO
        // =========================================================================
        return GeoLanguageResult(
            state = if (state.isNotBlank()) state else "República Mexicana",
            locality = locality.ifBlank { "Territorio Mesoamericano" },
            regionName = "Territorio del Anáhuac / México",
            languageCode = "Nahuatl",
            languageDisplayName = "Náhuatl",
            variantName = "Náhuatl Central / Imperial",
            culturalSummary = "La lengua franca ancestral más hablada y representativa de los pueblos originarios de México.",
            greetingPhrase = "¡Niltze! Te damos la bienvenida a las voces de nuestra tierra milenaria.",
            flagOrIcon = "🇲🇽",
            isExactRegionMatch = false
        )
    }
}
