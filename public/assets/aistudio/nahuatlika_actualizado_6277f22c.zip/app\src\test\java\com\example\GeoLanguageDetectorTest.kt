package com.example

import com.example.data.GeoLanguageDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeoLanguageDetectorTest {

    @Test
    fun testAllMajorRegionsOfMexicanRepublic() {
        // 1. Aguascalientes
        val ags = GeoLanguageDetector.resolveLanguageByRegion("Aguascalientes", "Aguascalientes", null, null)
        assertEquals("Nahuatl", ags.languageCode)

        // 2. Baja California
        val bc = GeoLanguageDetector.resolveLanguageByRegion("Baja California", "Tijuana", null, null)
        assertEquals("Nahuatl", bc.languageCode)

        // 3. Baja California Sur
        val bcs = GeoLanguageDetector.resolveLanguageByRegion("Baja California Sur", "La Paz", null, null)
        assertEquals("Nahuatl", bcs.languageCode)

        // 4. Campeche
        val camp = GeoLanguageDetector.resolveLanguageByRegion("Campeche", "Campeche", null, null)
        assertEquals("Maya", camp.languageCode)

        // 5. Chiapas
        val chis = GeoLanguageDetector.resolveLanguageByRegion("Chiapas", "Tuxtla", null, null)
        assertEquals("Maya", chis.languageCode)
        assertEquals("Nosótrico Tojolabal", chis.variantName)

        // 6. Chihuahua
        val chih = GeoLanguageDetector.resolveLanguageByRegion("Chihuahua", "Chihuahua", null, null)
        assertEquals("Nahuatl", chih.languageCode)

        // 7. Ciudad de México
        val cdmx = GeoLanguageDetector.resolveLanguageByRegion("Ciudad de México", "Cuauhtémoc", null, null)
        assertEquals("Nahuatl", cdmx.languageCode)
        assertEquals("Náhuatl Central / Imperial", cdmx.variantName)

        // 8. Coahuila
        val coah = GeoLanguageDetector.resolveLanguageByRegion("Coahuila", "Saltillo", null, null)
        assertEquals("Nahuatl", coah.languageCode)

        // 9. Colima
        val col = GeoLanguageDetector.resolveLanguageByRegion("Colima", "Colima", null, null)
        assertEquals("Nahuatl", col.languageCode)

        // 10. Durango
        val dgo = GeoLanguageDetector.resolveLanguageByRegion("Durango", "Durango", null, null)
        assertEquals("Nahuatl", dgo.languageCode)

        // 11. Estado de México
        val edomex = GeoLanguageDetector.resolveLanguageByRegion("Estado de México", "Toluca", null, null)
        assertEquals("Nahuatl", edomex.languageCode)

        // 12. Guanajuato
        val gto = GeoLanguageDetector.resolveLanguageByRegion("Guanajuato", "San Miguel de Allende", null, null)
        assertEquals("Otomi", gto.languageCode)

        // 13. Guerrero
        val gro = GeoLanguageDetector.resolveLanguageByRegion("Guerrero", "Chilapa", null, null)
        assertEquals("Nahuatl", gro.languageCode)
        assertEquals("Asertivo de Guerrero", gro.variantName)

        // 14. Hidalgo
        val hgo = GeoLanguageDetector.resolveLanguageByRegion("Hidalgo", "Ixmiquilpan", null, null)
        assertEquals("Otomi", hgo.languageCode)
        assertEquals("Viento de Mezquital", hgo.variantName)

        // 15. Jalisco
        val jal = GeoLanguageDetector.resolveLanguageByRegion("Jalisco", "Guadalajara", null, null)
        assertEquals("Nahuatl", jal.languageCode)

        // 16. Michoacán
        val mich = GeoLanguageDetector.resolveLanguageByRegion("Michoacán", "Morelia", null, null)
        assertEquals("Nahuatl", mich.languageCode)

        // 17. Morelos
        val mor = GeoLanguageDetector.resolveLanguageByRegion("Morelos", "Cuernavaca", null, null)
        assertEquals("Nahuatl", mor.languageCode)

        // 18. Nayarit
        val nay = GeoLanguageDetector.resolveLanguageByRegion("Nayarit", "Tepic", null, null)
        assertEquals("Nahuatl", nay.languageCode)

        // 19. Nuevo León
        val nl = GeoLanguageDetector.resolveLanguageByRegion("Nuevo León", "Monterrey", null, null)
        assertEquals("Nahuatl", nl.languageCode)

        // 20. Oaxaca
        val oaxZapoteco = GeoLanguageDetector.resolveLanguageByRegion("Oaxaca", "Juchitán", null, null)
        assertEquals("Zapoteco", oaxZapoteco.languageCode)
        val oaxMixteco = GeoLanguageDetector.resolveLanguageByRegion("Oaxaca", "Huajuapan de León", null, null)
        assertEquals("Mixteco", oaxMixteco.languageCode)

        // 21. Puebla
        val pueblaTehuacan = GeoLanguageDetector.resolveLanguageByRegion("Puebla", "Tehuacán", 18.4, -97.3)
        assertEquals("Nahuatl", pueblaTehuacan.languageCode)
        val pueblaCuetzalan = GeoLanguageDetector.resolveLanguageByRegion("Puebla", "Cuetzalan", 20.0, -97.5)
        assertEquals("Totona", pueblaCuetzalan.languageCode)

        // 22. Querétaro
        val qro = GeoLanguageDetector.resolveLanguageByRegion("Querétaro", "Amealco", null, null)
        assertEquals("Otomi", qro.languageCode)
        assertEquals("Acento Lelé Queretano", qro.variantName)

        // 23. Quintana Roo
        val qroo = GeoLanguageDetector.resolveLanguageByRegion("Quintana Roo", "Cancún", null, null)
        assertEquals("Maya", qroo.languageCode)

        // 24. San Luis Potosí
        val slp = GeoLanguageDetector.resolveLanguageByRegion("San Luis Potosí", "Xilitla", null, null)
        assertEquals("Nahuatl", slp.languageCode)

        // 25. Sinaloa
        val sin = GeoLanguageDetector.resolveLanguageByRegion("Sinaloa", "Culiacán", null, null)
        assertEquals("Nahuatl", sin.languageCode)

        // 26. Sonora
        val son = GeoLanguageDetector.resolveLanguageByRegion("Sonora", "Hermosillo", null, null)
        assertEquals("Nahuatl", son.languageCode)

        // 27. Tabasco
        val tab = GeoLanguageDetector.resolveLanguageByRegion("Tabasco", "Villahermosa", null, null)
        assertEquals("Nahuatl", tab.languageCode)
        assertEquals("Fusión Maya-Chontal", tab.variantName)

        // 28. Tamaulipas
        val tamps = GeoLanguageDetector.resolveLanguageByRegion("Tamaulipas", "Tampico", null, null)
        assertEquals("Nahuatl", tamps.languageCode)

        // 29. Tlaxcala
        val tlax = GeoLanguageDetector.resolveLanguageByRegion("Tlaxcala", "Tlaxcala", null, null)
        assertEquals("Nahuatl", tlax.languageCode)
        assertEquals("Consonante limpia de la Malinche", tlax.variantName)

        // 30. Veracruz
        val verPapantla = GeoLanguageDetector.resolveLanguageByRegion("Veracruz", "Papantla", null, null)
        assertEquals("Totona", verPapantla.languageCode)
        assertEquals("Ceremonial de Papantla", verPapantla.variantName)

        val verHuasteca = GeoLanguageDetector.resolveLanguageByRegion("Veracruz", "Chicontepec", null, null)
        assertEquals("Nahuatl", verHuasteca.languageCode)
        assertEquals("Náhuatl de la Huasteca veracruzana", verHuasteca.variantName)

        // 31. Yucatán
        val yuc = GeoLanguageDetector.resolveLanguageByRegion("Yucatán", "Mérida", null, null)
        assertEquals("Maya", yuc.languageCode)
        assertEquals("Maya Yucateco Glotalizado", yuc.variantName)

        // 32. Zacatecas
        val zac = GeoLanguageDetector.resolveLanguageByRegion("Zacatecas", "Zacatecas", null, null)
        assertEquals("Nahuatl", zac.languageCode)
    }
}
