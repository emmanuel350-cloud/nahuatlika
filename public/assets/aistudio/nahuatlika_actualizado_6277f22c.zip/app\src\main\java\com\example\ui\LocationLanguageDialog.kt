package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.data.GeoLanguageResult
import com.example.ui.theme.*

/**
 * Beautiful Mesoamerican Dialog that prompts for location permissions and
 * presents the automatically detected regional indigenous language and variant.
 */
@Composable
fun LocationLanguagePromptDialog(
    viewModel: MainViewModel,
    detectedResult: GeoLanguageResult?,
    isDetecting: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fineGranted || coarseGranted) {
            hasLocationPermission = true
            viewModel.detectLanguageFromCurrentLocation(context)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .padding(vertical = 24.dp),
            shape = RoundedCornerShape(26.dp),
            color = ObsidianDark,
            border = BorderStroke(1.5.dp, Brush.verticalGradient(listOf(GoldSun, TerracottaTezontle)))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Icon
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(GoldSun.copy(alpha = 0.15f))
                        .border(1.5.dp, GoldSun, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = detectedResult?.flagOrIcon ?: "📍",
                        fontSize = 32.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "DETECCIÓN TERRITORIAL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    color = GoldSun
                )

                Text(
                    text = "Lengua Originaria de tu Región",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = SandBeige,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (isDetecting) {
                    Spacer(modifier = Modifier.height(20.dp))
                    CircularProgressIndicator(color = GoldSun, strokeWidth = 3.dp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Consultando el mapa ancestral y coordenadas GPS...",
                        fontSize = 13.sp,
                        color = Color.LightGray,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                } else if (!hasLocationPermission) {
                    // Permission Request Prompt
                    Text(
                        text = "Para sugerirte con total precisión la lengua indígena y variante que floreció en tu tierra (Náhuatl, Totonaco, Maya, Zapoteco, Mixteco u Otomí), necesitamos acceso a tu ubicación.",
                        fontSize = 13.sp,
                        color = SoftClay,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    Button(
                        onClick = {
                            permissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldSun, contentColor = ObsidianDark),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Activar Permisos de Ubicación", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                } else if (detectedResult != null) {
                    // Result Display
                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = ObsidianCard,
                        border = BorderStroke(1.dp, GoldSun.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("📍", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${detectedResult.locality}, ${detectedResult.state}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldSun
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = detectedResult.regionName,
                                fontSize = 11.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Medium
                            )

                            Divider(
                                color = Color.White.copy(alpha = 0.1f),
                                modifier = Modifier.padding(vertical = 10.dp)
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Lengua Ancestral:",
                                        fontSize = 11.sp,
                                        color = Color.LightGray
                                    )
                                    Text(
                                        text = detectedResult.languageDisplayName.uppercase(),
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Black,
                                        color = when (detectedResult.languageCode) {
                                            "Totona" -> PapantlaGold
                                            "Maya" -> MayaTurquoise
                                            "Zapoteco" -> ZapotecRuby
                                            "Mixteco" -> MixtecViolet
                                            "Otomi" -> EmeraldJade
                                            else -> GoldSun
                                        }
                                    )
                                    Text(
                                        text = detectedResult.variantName,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = SandBeige
                                    )
                                }

                                Text(detectedResult.flagOrIcon, fontSize = 34.sp)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = detectedResult.culturalSummary,
                                fontSize = 12.sp,
                                color = SoftClay,
                                lineHeight = 16.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Greeting phrase with Victor Florencio's voice preview
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.Black.copy(alpha = 0.4f),
                                border = BorderStroke(0.8.dp, GoldSun.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.synthesizeSacerdotePhrase(detectedResult.greetingPhrase)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.VolumeUp,
                                        contentDescription = "Escuchar",
                                        tint = GoldSun,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "\"${detectedResult.greetingPhrase}\"",
                                        fontSize = 12.sp,
                                        color = SandBeige,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "Voz Víctor",
                                        fontSize = 9.sp,
                                        color = GoldSun,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Action: Apply this language
                    Button(
                        onClick = {
                            viewModel.applyDetectedGeoLanguage(detectedResult)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when (detectedResult.languageCode) {
                                "Totona" -> PapantlaGold
                                "Maya" -> MayaTurquoise
                                "Zapoteco" -> ZapotecRuby
                                "Mixteco" -> MixtecViolet
                                "Otomi" -> EmeraldJade
                                else -> GoldSun
                            },
                            contentColor = ObsidianDark
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Aprender ${detectedResult.languageDisplayName} (${detectedResult.variantName.take(18)}...)",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                TextButton(
                    onClick = onDismiss,
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.LightGray)
                ) {
                    Text("Cerrar y elegir manualmente", fontSize = 12.sp)
                }
            }
        }
    }
}

/**
 * Quick access button / card that can be rendered anywhere in the UI to trigger
 * the location permission request and language detection.
 */
@Composable
fun LocationLanguageQuickBanner(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fineGranted || coarseGranted) {
            viewModel.detectLanguageFromCurrentLocation(context)
        }
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = ObsidianCard,
        border = BorderStroke(1.dp, GoldSun.copy(alpha = 0.4f)),
        modifier = modifier
            .fillMaxWidth()
            .clickable {
                val hasPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

                if (hasPermission) {
                    viewModel.detectLanguageFromCurrentLocation(context)
                } else {
                    permissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                }
            }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(GoldSun.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.NearMe,
                    contentDescription = null,
                    tint = GoldSun,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "📍 Detectar mi lengua originaria",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = SandBeige
                )
                Text(
                    text = "Toca para saber qué lengua se habla en tu tierra por GPS",
                    fontSize = 10.5.sp,
                    color = Color.LightGray
                )
            }

            Icon(
                Icons.Default.ChevronRight,
                contentDescription = null,
                tint = GoldSun,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
